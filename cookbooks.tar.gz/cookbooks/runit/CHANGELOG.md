## v0.15.0:

* [COOK-1008] - Added parameters for names of different templates in runit
