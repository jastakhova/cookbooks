#
# Cookbook Name:: riak
#

default.riak.eleveldb.data_root = "/var/lib/riak/leveldb"

